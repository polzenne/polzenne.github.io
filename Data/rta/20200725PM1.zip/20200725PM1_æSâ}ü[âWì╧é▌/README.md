## 用途

- 素材や設定ファイルのバージョン管理に利用する。
- Googleドライブは1つ1つダウンロードしてコピーする必要があり面倒。

## ダウンロード手順
- download.batをダブルクリックで実行する。

## アップロード手順
- upload.batをダブルクリックで実行する。

## 初回手順

- Gitのインストール

  - 下記サイトにアクセスし、Downloadを押下  
  https://gitforwindows.org/
  - ダウンロードしてきたインストーラを実行する
  - 全てデフォルトでNextを押下し、インストール完了したらFinish

- リポジトリデータのダウンロード
  - ウディタを管理したいフォルダを新規作成し、フォルダ内でアドレスバーに`cmd`を入力
  - 下記を入力する
  ```
  git config --global user.name "自分の名前"
  git config --global user.email "自分のメールアドレス"
  git clone https://github.com/polzenne/RTA.git
  ```

- 作業用データをコピーしてくる
  - 作成されるフォルダに、これまで使用していたゲームデータごとコピー
  - エディタの起動確認を行う

## 注意事項

- 管理対象は下記フォルダ以下のみです。
  - それ以外のフォルダを新規追加する場合は、バッチファイルを修正する必要があります。

```
Data\Debug
Data\BackGroundGraphic
Data\BGM
Data\CharacterGraphic
Data\EffectGraphic
Data\EnemyGraphic
Data\IconGrapchic
Data\SE
Data\Story
Data\UIGraphic
Game
マージ用
```

- 基本的に、download.batを実行してからupload.batを実行してください。


---

## バッチファイルを使わない手順

- 初回
```
git clone https://github.com/polzenne/RTA.git
```

- リポジトリにデータをアップロード
```
git add "更新したファイルやフォルダを記述"
git commit -m "コミット時の文章を記述"
git push
```

- リポジトリからデータをダウンロード
```
git pull
```

## 誤ってアップロードした場合

- 下記コマンドで取り消したいコミットのIDを確認する
  ```
  git log
  ```
- 下記コマンドで対象のコミットを取り消す
  ```
  git revert --no-edit <commit ID>
  ```
- 再度upload.batを実行する

## 特定のコミットまで戻したい場合

- 下記コマンドで戻りたいコミットのIDを確認する
  ```
  git log
  ```
- 下記コマンドで対象のコミットを取り消す
  ```
  git reset --hard <commit ID>
  ```
- 再度upload.batを実行する

## 上のリセットが誤りだった場合

- 下記コマンドで直前のリセットを元に戻す
  ```
  git reset --hard ORIG_HEAD
  ```
- 再度upload.batを実行する
